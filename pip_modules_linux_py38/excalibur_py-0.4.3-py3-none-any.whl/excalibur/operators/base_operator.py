# -*- coding: utf-8 -*-


class BaseOperator(object):
    def __init__(self):
        pass

    def execute(self):
        pass
