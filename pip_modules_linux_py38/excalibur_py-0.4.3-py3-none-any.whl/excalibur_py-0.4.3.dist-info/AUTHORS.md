This file contains a list of core contributors and maintainers.

- Vinayak Mehta <vmehta94@gmail.com>, 2018-10-20
- Nikhil Sikka <ns.sikka@gmail.com>, 2018-10-20
